﻿// Tablesorter extensions

